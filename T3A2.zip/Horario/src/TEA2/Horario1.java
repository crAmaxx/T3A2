
package TEA2;

import java.util.Scanner;
public class Horario1 {
    private int horario;
    private int horario1;
    private int reloj1;
    private int reloj2;
    private int resultado;
    
    public Horario1 () {}

 

    public Horario1(int horario, int horario1, int reloj1, int reloj2, int resultado) {
        this.horario = horario;
        this.horario1 = horario1;
        this.reloj1 = reloj1;
        this.reloj2 = reloj2;
        this.resultado = resultado;
    }

   

    @Override
    public String toString() {
        return  "dia de semana ordenada por numeros" + "\n1.lunes" + "\n2.martes" + "\n3.miercoles" + "\n4.jueves" + "\n5.viernes" + "\n6.sabado" + "/n7.domingo" + "el tiempo qe ha transcurrido del dia " + horario + " a " + horario1 + " son " + resultado;
    }

    public int getHorario() {
        return horario;
    }

    public void setHorario(int horario) {
        this.horario = horario;
    }

    public int getHorario1() {
        return horario1;
    }

    public void setHorario1(int horario1) {
        this.horario1 = horario1;
    }

    public int getReloj1() {
        return reloj1;
    }

    public void setReloj1(int reloj1) {
        this.reloj1 = reloj1;
    }

    public int getReloj2() {
        return reloj2;
    }

    public void setReloj2(int reloj2) {
        this.reloj2 = reloj2;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }
    
           
}
