
package TEA2;

import java.util.Scanner;
public class Horario {

   
    public static void main(String[] args) {
       saludo ();
    }
   public static void saludo (){
       int resultado1;
       int resultado;
       int resultado2;
       
       
       Scanner h=new Scanner (System.in);
       Horario1 p=new Horario1 ();
       System.out.println("1.lunes");
       System.out.println("2.martes");
       System.out.println("3.miercoles");
       System.out.println("4.jueves");
       System.out.println("5.viernes");
       System.out.println("6.sabado");
       System.out.println("7.domingo");
       
       
       System.out.println("ingresa el primer dia que requieres en numeros (del uno al siete)");
       int horario =h.nextInt();
       p.setHorario(horario);
       
       
       System.out.println ("por favor ingresa el horario del prmier dia");
       int reloj1=h.nextInt();
       p.setReloj1(reloj1);
       
       
       System.out.println ("ingrese el dia del segundo dia");
       int horario1=h.nextInt();
       p.setHorario1(horario1);
       
       System.out.println ("ingrese el horario del segundo dia");
       int reloj2=h.nextInt();
       p.setReloj2(reloj2);
       
       if (horario>7 && horario1>7){
           System.out.println ("por favor ingrese el valor correctamente");
       }
       else {
            if (horario==1 && horario1==1){
                System.out.println ("todavia no");
            }
           if (horario==1 && horario1==2){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
            if (horario==1 && horario1==3){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+24+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
            if (horario==1 && horario1==4){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+24+24+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
            if (horario==1 && horario1==5){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+24+24+24+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
            if (horario==1 && horario1==6){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+24+24+24+24+24+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
            if (horario==1 && horario1==7){
               resultado1=24-reloj1;
               resultado2=24-reloj2;
               resultado=resultado1+24+24+24+24+24+resultado2;
               p.setResultado(resultado);
               System.out.println ("el resultado es" + p.toString());
               
               
           }
           
            if (horario==2 && horario<=2){
                System.out.println ("todavia no");
            }
          
            if (horario ==2 && horario1==3){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
            if (horario ==2 && horario1==4){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
            if (horario ==2 && horario1==5){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
            if (horario ==2 && horario1==6){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+24+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
            if (horario ==2 && horario1==7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+24+24+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
            if (horario ==3 && horario1<=3){
                System.out.println ("todavia no");
            }
            if (horario ==3 && horario1==4){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
             if (horario ==3 && horario1==5){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
              if (horario ==3 && horario1==6){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
               if (horario ==3 && horario1==7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+24+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
               if (horario==4 && horario1<=4){
                   System.out.println ("todavia no");
               }
                if (horario ==4 && horario1==5){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
               if (horario ==4 && horario1==6){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
               if (horario ==4 && horario1==7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
               if (horario==5 && horario1<=5){
                   System.out.println ("todavia no");
               }
               if (horario ==5 && horario1==6){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }  
             if (horario ==5 && horario1==7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
            }
             if (horario==6 && horario1<=6){
                   System.out.println ("todavia no");
               }
             if (horario ==6 && horario1==7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+resultado2;
              p.setResultado(resultado);
              System.out.println ("el resultado es" + p.toString());
             }
             if (horario ==7 && horario1<=7){
              resultado1=24-reloj1;
              resultado2=24-reloj2;
              resultado=resultado1+24+resultado2;
              p.setResultado(resultado);
              System.out.println ("por favor, agrega bien los dias");
            }
            
       }
   }
   } 

